package exfinal;

public interface Volant {
    void Voller();
}
