package exfinal;

public class Test {
    public static void main(String[] args) {
        Vehicule[] vehicules = {
            new Voiture("Voiture1", "Essence"),
            new Bateau("Bateau1", "Diesel"),
            new Hydravion("Hydravion1", "K�ros�ne")
        };

        for (Vehicule v : vehicules) {
            v.demarrer();
            v.afficherInfos();
            v.arreter();

            if (v instanceof Roulant) {
                ((Roulant) v).rouler();
            }
            if (v instanceof Flottant) {
                ((Flottant) v).flotter();
            }
            System.out.println();
        }
    }
}
