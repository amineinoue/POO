package exfinal;

class Hydravion extends Vehicule implements Volant, Flottant {
    public Hydravion(String nom, String typeCarburant) {
        super(nom, typeCarburant);
    }

    @Override
    public void demarrer() {
        System.out.println("L'hydravion d�marre.");
    }

    @Override
    public void arreter() {
        System.out.println("L'hydravion s'arr�te.");
    }

    public void voler() {
        System.out.println("L'hydravion vole.");
    }

    public void flotter() {
        System.out.println("L'hydravion flotte.");
    }

	public void Voller() {
		// TODO Auto-generated method stub
		
	}
}

