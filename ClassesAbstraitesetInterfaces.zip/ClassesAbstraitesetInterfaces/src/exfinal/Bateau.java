package exfinal;

class Bateau extends Vehicule implements Flottant {
    public Bateau(String nom, String typeCarburant) {
        super(nom, typeCarburant);
    }

    @Override
    public void demarrer() {
        System.out.println("Le bateau d�marre.");
    }

    @Override
    public void arreter() {
        System.out.println("Le bateau s'arr�te.");
    }

    public void flotter() {
        System.out.println("Le bateau flotte.");
    }
}
