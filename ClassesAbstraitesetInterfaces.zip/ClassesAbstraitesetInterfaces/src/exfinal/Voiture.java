package exfinal;

class Voiture extends Vehicule implements Roulant {
    public Voiture(String nom, String typeCarburant) {
        super(nom, typeCarburant);
    }

    @Override
    public void demarrer() {
        System.out.println("La voiture d�marre.");
    }

    @Override
    public void arreter() {
        System.out.println("La voiture s'arr�te.");
    }

    public void rouler() {
        System.out.println("La voiture roule.");
   }
    
}
