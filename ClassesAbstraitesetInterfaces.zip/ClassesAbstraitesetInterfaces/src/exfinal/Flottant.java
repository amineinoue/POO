package exfinal;

public interface Flottant {
	void flotter();
}
