package exfinal;

public interface Roulant {
	
	    void rouler();
	
}
