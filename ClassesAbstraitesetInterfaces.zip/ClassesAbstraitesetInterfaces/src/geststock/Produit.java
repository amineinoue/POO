package geststock;

interface Produit {
    double calculerValeurStock();
}
