package geststock;

class ProduitElectronique implements Produit {
    private double prixUnitaire;
    private int quantite;

    public ProduitElectronique(double prixUnitaire, int quantite) {
        this.prixUnitaire = prixUnitaire;
        this.quantite = quantite;
    }

    public double calculerValeurStock() {
        return prixUnitaire * quantite;
    }
}
