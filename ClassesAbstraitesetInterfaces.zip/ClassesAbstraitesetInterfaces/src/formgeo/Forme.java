package formgeo;

abstract class Forme {
    abstract double calculerSurface();
    abstract double calculerPerimetre();
}
