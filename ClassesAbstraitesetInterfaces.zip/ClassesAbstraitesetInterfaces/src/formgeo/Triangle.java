package formgeo;

class Triangle extends Forme {
    private double cote;

    public Triangle(double cote) {
        this.cote = cote;
    }

    @Override
    double calculerSurface() {
        return (Math.sqrt(3) / 4) * cote * cote;
    }

    @Override
    double calculerPerimetre() {
        return 3 * cote;
    }
}
