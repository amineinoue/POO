package exbasique;

public class Velo extends Vehicule {
    
    public void seDeplacer() {
        System.out.println("Le v�lo se d�place sur la route");
    }
}