package exbasique;

public class Vehicule {
    public void seDeplacer() {
       
    }
    
    
    
 

 

}

