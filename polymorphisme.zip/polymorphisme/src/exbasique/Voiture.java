package exbasique;

public class Voiture extends Vehicule {
    
    public void seDeplacer() {
        System.out.println("La voiture se deplace sur la route");
    }
}