package ex;


public class Ex1 {
    public static void main(String[] args) {
        int a = 10;
        int b = 0;
        
        try {
            int result = a / b;
        } catch (ArithmeticException e) {
            System.out.println("Erreur : Division par z�ro !");
        } finally {
            System.out.println("Bloc finally ex�cut�. Le programme s'est termin�.");
        }
    }
}

